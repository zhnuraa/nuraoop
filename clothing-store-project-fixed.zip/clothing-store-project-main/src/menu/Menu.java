package menu;

public interface Menu {
    void displayMenu();
    void run();
}
